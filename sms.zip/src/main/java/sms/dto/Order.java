package sms.dto;

public class Order {

}
