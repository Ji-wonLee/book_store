package sms.dto;

public class OrderDetail {

}
