package sms.controller;

public class SearchListController {
	
}
